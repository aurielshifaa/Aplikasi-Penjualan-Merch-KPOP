<?php
session_start();
require "js/koneksi.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $produk_id = $_POST['produk_id'];
    $jumlah = $_POST['jumlah'];

    // Ambil data produk dari database
    $query = mysqli_query($conn, "SELECT id, nama, harga, foto FROM produk WHERE id='$produk_id'");
    $produk = mysqli_fetch_assoc($query);

    if (!$produk) {
        die("Produk tidak ditemukan.");
    }

    // Buat item keranjang
    $item = [
        'id' => $produk['id'],
        'nama' => $produk['nama'],
        'harga' => $produk['harga'],
        'foto' => $produk['foto'],
        'jumlah' => $jumlah
    ];

    // Tambahkan ke session keranjang
    if (!isset($_SESSION['keranjang'])) {
        $_SESSION['keranjang'] = [];
    }

    // Jika produk sudah ada, tambahkan jumlah
    $found = false;
    foreach ($_SESSION['keranjang'] as $key => $existingItem) {
        if ($existingItem['id'] == $produk_id) {
            $_SESSION['keranjang'][$key]['jumlah'] += $jumlah;
            $found = true;
            break;
        }
    }

    if (!$found) {
        $_SESSION['keranjang'][] = $item;
    }

    header("Location: keranjang.php");
    exit;
}
?>