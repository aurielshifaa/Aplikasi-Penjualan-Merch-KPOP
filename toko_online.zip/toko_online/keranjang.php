<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$keranjang = isset($_SESSION['keranjang']) ? $_SESSION['keranjang'] : [];

if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    unset($_SESSION['keranjang'][$id]);
    header("Location: keranjang.php");
    exit;
}

if (isset($_GET['tambah'])) {
    $id = $_GET['tambah'];
    if (isset($_SESSION['keranjang'][$id])) {
        $_SESSION['keranjang'][$id]['jumlah'] += 1;
    }
    header("Location: keranjang.php");
    exit;
}

if (isset($_GET['kurang'])) {
    $id = $_GET['kurang'];
    if (isset($_SESSION['keranjang'][$id])) {
        $_SESSION['keranjang'][$id]['jumlah'] -= 1;
        if ($_SESSION['keranjang'][$id]['jumlah'] <= 0) {
            unset($_SESSION['keranjang'][$id]);
        }
    }
    header("Location: keranjang.php");
    exit;
}

$jumlahItem = count($keranjang);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Keranjang Belanja</title>
    <link rel="stylesheet" href="bootstrap/bootstrap-5.3.6-dist/css/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            position: relative; }
        .warna1 {
            background-color: #3c0663;
        }
    </style>
    <script>
        function updateTotal() {
            const checkboxes = document.querySelectorAll('.produk-check');
            let total = 0;
            checkboxes.forEach(cb => {
                if (cb.checked) {
                    total += parseInt(cb.dataset.subtotal);
                }
            });

            document.getElementById('totalBelanja').innerText = total.toLocaleString('id-ID', {
                style: 'currency',
                currency: 'IDR',
                minimumFractionDigits: 0
            });
        }
    </script>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark warna1">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false"
            aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
            <!-- Menu Kiri -->
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item me-4"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item me-4"><a class="nav-link" href="tentang-kami.php">Tentang Kami</a></li>
                <li class="nav-item me-4"><a class="nav-link" href="produk.php">Produk</a></li>
            </ul>

            <!-- Menu Kanan: Keranjang -->
            <ul class="navbar-nav mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link position-relative" href="keranjang.php">
                        <i class="fas fa-shopping-cart"></i> Keranjang
                        <?php if ($jumlahItem > 0): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                <?= $jumlahItem; ?>
                            </span>
                        <?php endif; ?>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- HALAMAN KERANJANG -->
<div class="container mt-5">
    <h2>Keranjang Belanja</h2>

    <?php if (empty($keranjang)): ?>
        <p>Keranjang masih kosong.</p>
    <?php else: ?>
        <form method="post" action="checkout.php" id="formKeranjang">
            <table class="table table-bordered mt-3">
                <thead>
                <tr>
                    <th>Pilih</th>
                    <th>Foto</th>
                    <th>Produk</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Total</th>
                    <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($keranjang as $id => $item): ?>
                    <?php $subtotal = $item['harga'] * $item['jumlah']; ?>
                    <tr>
                        <td>
                            <input type="checkbox" name="produk_id[]" value="<?= $id ?>"
                                   class="form-check-input produk-check"
                                   data-subtotal="<?= $subtotal ?>" onclick="updateTotal()">
                        </td>
                        <td><img src="image/<?= $item['foto']; ?>" width="70"></td>
                        <td><?= $item['nama']; ?></td>
                        <td>Rp <?= number_format($item['harga'], 0, ',', '.'); ?></td>
                        <td>
                            <div class="d-flex align-items-center">
                                <a href="?kurang=<?= $id ?>" class="btn btn-sm btn-secondary me-1">-</a>
                                <?= $item['jumlah']; ?>
                                <a href="?tambah=<?= $id ?>" class="btn btn-sm btn-secondary ms-1">+</a>
                            </div>
                        </td>
                        <td>Rp <?= number_format($subtotal, 0, ',', '.'); ?></td>
                        <td>
                            <a href="?hapus=<?= $id ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus produk ini?')">Hapus</a>
                        </td>

                        <!-- Data produk untuk JS, bukan untuk dikirim langsung -->
                        <input type="hidden" class="produk-data-id" value="<?= $id ?>">
                        <input type="hidden" class="produk-data-nama" value="<?= $item['nama'] ?>">
                        <input type="hidden" class="produk-data-harga" value="<?= $item['harga'] ?>">
                        <input type="hidden" class="produk-data-jumlah" value="<?= $item['jumlah'] ?>">
                        <input type="hidden" class="produk-data-total" value="<?= $subtotal ?>">
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <h4>Total Belanja: <span id="totalBelanja">Rp 0</span></h4>
            <button type="submit" class="btn btn-success mt-3">Checkout</button>
        </form>
    <?php endif; ?>
</div>

<script src="bootstrap/bootstrap-5.3.6-dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Hanya kirim produk yang dicentang saat submit
    document.getElementById('formKeranjang').addEventListener('submit', function(e) {
        // Hapus input produk hidden sebelumnya
        document.querySelectorAll('.produk-hidden').forEach(el => el.remove());

        // Tambahkan input produk hanya untuk yang dicentang
        document.querySelectorAll('.produk-check:checked').forEach(cb => {
            const row = cb.closest('tr');
            const id = cb.value;
            ['id','nama','harga','jumlah','total'].forEach(field => {
                const val = row.querySelector('.produk-data-' + field).value;
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = `produk[${id}][${field}]`;
                input.value = val;
                input.classList.add('produk-hidden');
                this.appendChild(input);
            });
        });

        // Jika tidak ada produk yang dicentang, batalkan submit
        if (document.querySelectorAll('.produk-check:checked').length === 0) {
            alert('Pilih minimal satu produk untuk checkout!');
            e.preventDefault();
        }
    });
</script>
</body>
</html>