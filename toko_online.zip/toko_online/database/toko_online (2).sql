-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2025 at 05:36 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `toko_online`
--

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `nama`) VALUES
(1, 'Album'),
(2, 'Lightstick'),
(3, 'merchandise');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `kategori_id` int(11) DEFAULT NULL,
  `nama` varchar(225) DEFAULT NULL,
  `harga` double DEFAULT NULL,
  `foto` varchar(225) DEFAULT NULL,
  `detail` text DEFAULT NULL,
  `ketersediaan_stok` enum('habis','tersedia') DEFAULT 'tersedia'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id`, `kategori_id`, `nama`, `harga`, `foto`, `detail`, `ketersediaan_stok`) VALUES
(2, 2, 'ARMY BOMB (Ver.4) – BTS Lightstick', 750000, 'MpU8LdHJGCYLT18RMAbw.jfif', 'Lightstick official dari BTS ini hadir dalam versi ke-4 dengan desain elegan berwarna hitam dan bola bening bertabur glitter di bagian atas. Bisa terhubung via Bluetooth untuk sync warna saat konser. Dilengkapi pouch, strap, dan photocard member. Wajib punya buat ARMY sejati!           ', 'tersedia'),
(3, 1, 'BTS Map of the Soul: 7', 362000, 'raMavl3Upb8hb5QGfOhN.jpg', 'Sealed DETAIL : CD,PHOTOBOOK,LYRIC BOOK,MINI BOOK,RANDOM PHOTOCARD,POSTCARD,STICKER,COLOURING PAPER NO POSTER', 'tersedia'),
(4, 1, 'NCT Dream ISTJ', 310000, '0ZyeOBarCFGWlZJK7Npu.jfif', 'free photocard', 'tersedia'),
(5, 3, 'NewJeans - SUPERNATURAL (Takashi Murakami Drawstring Bag Ver.)', 546000, 'sXHeGjCFYhbhw0WHW2cX.jfif', 'include :  CD,Postcard, Outbox, Photobook, Jewel case + Booklet', 'tersedia'),
(6, 3, 'blackpink - BORN VINYL PINK', 695000, '79YgBQyEhlbSqfroLkXA.jfif', 'Box Set 1LP •Limited Edition (Vinyl/PH/LP)', 'tersedia'),
(7, 1, 'SEVENTEEN – FML Mini Album', 350000, 'X7bXEdLJ3ZXDVlvzwAtK.jfif', '                        Deskripsi: Album ini berisi CD original, photobook eksklusif, photocard member secara acak, buku lirik, poster lipat acak, lenticular card, dan stiker yang menambah koleksi Anda.                    ', 'tersedia'),
(8, 1, 'Jeon Jung-kook - GOLDEN (SOLID) (D2C Exclusive)', 420000, 'uwjx4JqVIMp8pLwS90zr.jpg', '                        Deskripsi: Versi eksklusif ini dilengkapi CD album, photobook premium, postcard set, poster lipat, photocard edisi golden secara acak, serta kartu D2C eksklusif yang hanya tersedia dalam versi ini.                    ', 'tersedia'),
(11, 1, 'NEW JEANS 1st Single Album', 290000, '2oYOPqeMQjrzyM5L2E8y.jfif', '                        Deskripsi: Album ini hadir dengan CD, photobook penuh warna, ID card, photocard acak, message card spesial, dan dikemas dalam tas unik yang menjadi ciri khas New Jeans.                    ', 'tersedia'),
(12, 1, 'BTS - You Never Walk Alone', 330000, 'QsNrW2HuLi2W9lvm1LcH.jfif', '                                                Deskripsi: Terdiri dari CD original, photobook setebal 112 halaman, satu photocard acak, mini poster, serta poster lirik yang memperkuat kesan mendalam dari album ini.                                        ', 'tersedia'),
(13, 1, 'RED VELVET - Cosmic', 320000, 'f3c8TFGAQnw9uZlPTVpk.jfif', '                                                                                                                                                Deskripsi: Paket ini dilengkapi CD album, photobook bergaya futuristik, photocard acak, lenticular card, stiker, dan poster yang memanjakan penggemar.                                                                                                                        ', 'tersedia'),
(14, 1, 'ENHYPEN - Dimension: Dilemma', 340000, 'U3XZw4zYF4xvDjJq9n67.jfif', '                        Deskripsi: Album ini menyertakan CD, photobook elegan, photocard acak, folded poster, bookmark eksklusif, serta stiker menarik yang membuat koleksi semakin lengkap.                    ', 'tersedia'),
(15, 1, 'NCT 127 - Sticker', 350000, 'YnBlY8eyiBlLKWE7hqIq.jfif', 'Deskripsi: Anda akan mendapatkan CD, photobook menarik, satu sticker pack, photocard acak, dan poster spesial dari era &quot;Sticker&quot;.', 'tersedia'),
(16, 1, 'TREASURE - The Second Step: Chapter One', 330000, 'rP0S8qW7s6yvzMAj4Q2j.jfif', 'Deskripsi: Album ini menyertakan CD, photobook eksklusif, photocard dan selfie card acak, poster, serta AR card interaktif.\r\n\r\n', 'tersedia'),
(17, 1, 'LE SSERAFIM - Antifragile', 330000, '18J6MSLeZ0UrQGAKpwbs.png', 'Deskripsi: Berisi CD original, photobook dengan konsep kuat, poster, photocard acak, serta message card yang penuh makna.', 'tersedia'),
(18, 1, 'TXT - The Chaos Chapter: Freeze', 340000, '6iCXg9gzxCr64PCpOSQF.jfif', 'Deskripsi: Dilengkapi dengan CD, photobook, concept poster yang artistik, postcard, photocard acak, dan buku lirik resmi.\r\n\r\n', 'tersedia'),
(19, 2, 'Carat Bong – SEVENTEEN Lightstick Ver.2', 720000, '7X56pU8RgqNzwHtbwTFx.jfif', 'Lightstick resmi SEVENTEEN dengan kristal ikonik berbentuk berlian dan nuansa pink-biru khas Carat. Bisa connect via app dan sync saat konser. Packaging mewah dengan pouch, strap, dan photocard eksklusif. Bikin experience nonton konser makin magical!', 'tersedia'),
(20, 2, 'Zzz Bong – TXT (Tomorrow X Together)', 680000, '7J9rWRcqfA2rwTCcCwJO.jfif', 'Deskripsi: Desain simpel tapi unik dengan simbol “X” khas TXT di dalam globe bening. Support concert sync mode, hadir dengan strap, pouch, dan packaging estetik. Pilihan tepat buat MOA!', 'tersedia'),
(21, 2, 'Teu-Bong – TREASURE Lightstick', 670000, 'mXmNlg1wINyIxjnM13EA.jfif', 'Deskripsi: Lightstick resmi TREASURE dengan desain elegan menyerupai tongkat sihir berwarna biru metalik. Memiliki fitur Bluetooth dan concert sync mode. Logo TREASURE di bagian atas menyala terang, dan dilengkapi strap, pouch, serta box eksklusif. Pilihan terbaik untuk para Teume yang ingin tampil all out saat konser!', 'tersedia'),
(22, 2, 'Kimman-Bong – RED VELVET Lightstick', 650000, 'MtSNidrdizGjYM47IFbe.jfif', 'Deskripsi: Lightstick berwarna putih dengan aksen pink pastel dan logo RV berbentuk hati di bagian atas. Desain yang manis dan elegan ini hadir dengan fitur lampu multi-mode, Bluetooth, serta kemasan box resmi dan strap. Cocok banget buat ReVeluv yang classy dan colorful!', 'tersedia'),
(23, 2, 'ENHYPEN Official Lightstick', 680000, 'dARMASFdffwBtHMTa0Kx.jfif', '                        Deskripsi: Lightstick dengan tampilan futuristik berwarna hitam-silver dan logo ENHYPEN bercahaya biru di bagian dalam. Sudah support Bluetooth dan concert mode. Dalam satu paket sudah termasuk box premium, strap, dan photocard spesial untuk para ENGENE!                    ', 'tersedia'),
(24, 2, 'Official Lightstick – LE SSERAFIM', 700000, 'E962HvQR9WIrbxkfLM0C.jpg', '                        Deskripsi: Lightstick pertama dari LE SSERAFIM yang tampil elegan dengan warna putih bersih dan logo grup di bagian atas. Dilengkapi dengan fitur Bluetooth dan concert sync, serta hadir dengan box resmi, strap, dan photocard eksklusif. Simpel, cantik, dan powerful—persis seperti konsep grupnya!                    ', 'tersedia'),
(25, 2, 'Light Ring – ITZY Lightstick', 620000, 'CtQwxPgLjuDGznnF2GF1.jpg', 'Deskripsi: Bukan lightstick biasa! ITZY hadir dengan desain light ring unik yang bisa digenggam atau dikenakan. Warna dominan putih dengan aksen pink dan hitam, sudah support concert mode dan nyala LED yang bisa diatur. Paket dilengkapi strap dan packaging elegan. Perfect buat MIDZY yang berani beda!', 'tersedia'),
(26, 2, 'Hammer Bong Ver.2 – BLACKPINK Lightstick', 720000, '1JIkEVP9Q9zZU8Nk4Zo2.jfif', 'Deskripsi: Versi terbaru dari lightstick ikonik BLACKPINK berbentuk palu imut dengan warna pink-hitam khas grup. Bisa mengeluarkan suara squeaky lucu dan terhubung dengan app untuk concert sync. Nyala LED yang terang dan desainnya yang playful bikin BLINK tampil standout di venue!', 'tersedia'),
(27, 2, 'Binky Bong – NEWJEANS Lightstick', 740000, 'pEYGXnBKnYG5x5cxC7oN.jfif', 'Deskripsi: Lightstick official pertama dari NewJeans dengan desain super fresh dan cute bertema kelinci. Warna putih dengan aksen biru pastel, dilengkapi LED warna-warni dan fitur Bluetooth sync. Dikemas dalam box eksklusif, lengkap dengan strap dan photocard. Wajib banget buat para Bunnies!', 'tersedia'),
(28, 2, 'NCT Official Lightstick Ver.2 – NCT DREAM', 750000, 'DeDaWjTZ7bewyQsRwY2N.jfif', 'Deskripsi: Versi terbaru dari lightstick resmi NCT dengan desain kubus neon hijau yang kini hadir dengan finishing lebih glossy dan detail logo NCT yang diperbarui. Sudah support Bluetooth 5.0 dan mode konser yang bisa di-sync via aplikasi. Dapat digunakan untuk semua unit termasuk NCT DREAM. Dalam paket sudah termasuk box eksklusif, strap, dan pouch. Wajib punya untuk NCTzen yang ingin full experience saat konser!', 'tersedia'),
(29, 2, 'æ-Bong - AESPA Official Lightstick', 780000, 'H25TEpkTdaOxo6DWFtol.jpg', 'Deskripsi: Lightstick pertama dari aespa ini hadir dengan desain futuristik berbentuk bulat dengan logo “æ” menyala di bagian tengah. Warna dominan putih dengan aksen biru elektrik yang elegan. Dilengkapi fitur Bluetooth untuk concert sync dan beberapa mode nyala LED. Paket dilengkapi dengan box eksklusif, strap, dan photocard. Cocok banget buat MY yang ingin tampil futuristik dan stylish saat support aespa di konser!', 'tersedia'),
(30, 1, 'AESPA – MY WORLD (3rd Mini Album)', 320000, 'AmUa74Ch7zWk0kFeAZyZ.png', 'Deskripsi: Album penuh warna dari aespa ini hadir dalam beberapa versi (Zine, Digipack, dan Poster ver). Setiap paket berisi CD, photobook eksklusif, photocard acak member, postcard, stiker hologram, dan folded poster. Dengan konsep dreamy dan cyber-pop khas aespa, MY WORLD jadi koleksi wajib buat MY!', 'tersedia'),
(31, 3, 'aespa WEEK - #Whiplash_mood - HOODIE SET', 850000, 'x5NZMMLaNbPlJ7vgg1tB.jpg', 'Deskripsi: Hoodie eksklusif edisi aespa WEEK #Whiplash_mood ini hadir dengan desain minimalis tapi stylish khas aespa. Didesain dengan bahan katun premium yang nyaman dipakai harian maupun nonton konser. Set ini mencakup 1 hoodie (unisex fit), postcard set member aespa, dan packaging spesial edisi terbatas. Wajib dikoleksi oleh MY yang pengin tampil keren dengan sentuhan aespa vibes!', 'tersedia'),
(32, 3, ' V BTS – Mute Boston Bag (HYBE Artist-Made Collection)', 1450000, '2nK10sACadzugC8MF5d2.jfif', '                        Deskripsi: Tas eksklusif desain Kim Taehyung (V BTS) dari HYBE Artist-Made Collection ini hadir dengan model Boston Bag berwarna muted grey yang classy dan versatile. Dibuat dari bahan premium dengan detail embroidery &quot;V&quot;, tali adjustable &amp; detachable, serta kapasitas besar cocok untuk daily use atau traveling. Dalam paket termasuk dust bag, photocard V (limited), dan box packaging eksklusif. Wajib punya buat ARMY yang ingin tampil elegan ala V!                    ', 'tersedia'),
(33, 3, '[2025 BTS FESTA x Weverse] Coin Pouch', 280000, 'Ls1iX2Cmcs2U9qsjpTxP.jpg', 'Deskripsi: Dompet koin edisi terbatas dari event 2025 BTS FESTA x Weverse, hadir dengan desain ungu khas BTS dan logo FESTA yang elegan. Terbuat dari bahan kulit sintetis premium, berukuran compact namun cukup untuk menyimpan koin, earphone, atau aksesori kecil lainnya. Dilengkapi gantungan keyring dan packaging eksklusif FESTA. Item wajib buat ARMY yang suka koleksi barang cute dan fungsional!', 'tersedia'),
(34, 3, '[BEOMGYU] TXT Bracelet (Gold) – HYBE Artist-Made Collection', 520000, 'ldWAaoIpZF4cKdZGZZcR.jfif', 'Deskripsi: Gelang eksklusif berwarna emas hasil desain langsung dari Beomgyu TXT, bagian dari HYBE Artist-Made Collection. Memiliki desain simple namun elegan, dengan inisial tersembunyi sebagai detail personal dari Beomgyu. Terbuat dari bahan metal berkualitas tinggi dengan finishing gold plating, dilengkapi kotak kemasan eksklusif, pouch, dan photocard resmi Beomgyu. Pilihan sempurna untuk MOA yang suka tampil classy dan sentimental!', 'tersedia'),
(35, 3, 'LE SSERAFIM – Gym Bag (Fearless Blue)', 620000, '1n5WK94UJ167XD4yCvvP.png', 'Deskripsi: Tas gym eksklusif LE SSERAFIM edisi warna Fearless Blue ini hadir dengan desain sporty dan elegan. Dibuat dari bahan tahan air, ringan, dan kuat untuk kebutuhan harian atau olahraga. Logo “LE SSERAFIM” tercetak bold di sisi tas, lengkap dengan strap panjang adjustable dan pegangan tangan. Di dalamnya terdapat kompartemen utama luas dan saku dalam. Bonus tag gantungan logo dan packaging resmi. Wajib buat FEARNOT yang aktif dan penuh gaya!', 'tersedia'),
(36, 3, ' SEVENTEEN – IN THE SOOP OFFICIAL PAJAMA SET', 750000, 'zjZ9f3cG0awQWk1KO5pF.jfif', 'Deskripsi: Piyama eksklusif dari kolaborasi SEVENTEEN x IN THE SOOP, dengan bahan katun lembut dan motif logo Soop kecil. Tersedia dalam ukuran all-size unisex. Hadir dengan pouch eksklusif dan tag member. Cozy banget buat carat yang suka me time dengan style ala SVT.', 'tersedia'),
(37, 3, ' TREASURE – OFFICIAL BALL CAP [HELLO TOUR MERCH]', 360000, 's8OnXuPoVBnsnW0drQc8.jfif', 'Deskripsi: Topi resmi TREASURE dari rangkaian HELLO TOUR. Warna navy dengan bordiran logo TREASURE di depan dan tulisan &quot;HELLO&quot; di samping. Adjustable strap dan bahan nyaman dipakai outdoor. Simpel dan casual, cocok buat daily style para Teume!', 'tersedia'),
(38, 3, 'NCT WISH – 05 Pouch / 2025 NCT WISH THE 1ST PHOTO EXHIBITION [ONE SUMMER WISH] OFFICIAL MD', 340000, 'y9xLXnLBqz9vw2OXqYn3.jpg', 'Deskripsi: Pouch resmi dari event ONE SUMMER WISH – NCT WISH 1st Photo Exhibition ini hadir dengan desain clean dan elegan bernuansa pastel. Terbuat dari bahan nylon berkualitas yang ringan, tahan air, dan mudah dibersihkan. Cocok untuk menyimpan alat tulis, makeup, atau aksesoris kecil. Terdapat label woven dengan logo NCT WISH dan nomor “05” sebagai identitas grup. Setiap pembelian disertai packaging eksklusif event dan tag resmi. Wajib untuk WISH yang ingin koleksi merchandise memorable dan fungsional!', 'tersedia'),
(39, 3, 'Red Velvet – 01 Folding UV Umbrella + Umbrella Keyring Set', 460000, '7LpgAOMfG2UWCGV4wvww.jpg', 'Deskripsi: Set eksklusif dari official merchandise Red Velvet [Cosmic] 2024 ini berisi payung lipat anti-UV dan gantungan kunci mini berbentuk payung dengan desain yang senada. Payung berukuran compact namun kuat, dilapisi bahan UV protection, cocok untuk cuaca panas maupun hujan. Dihiasi motif bertema “Cosmic” yang elegan dan girly, lengkap dengan pouch penyimpanan. Gantungan kunci mini hadir dengan detail lucu dan logo Red Velvet. Satu set yang wajib dimiliki ReVeluv untuk tampil manis dan siap cuaca apapun!', 'tersedia'),
(40, 3, 'Red Velvet – STAMP PACKAGE _ Chill Kill', 310000, 'h27rB6AOXlti6yJjKLVZ.jpg', 'Deskripsi: Merchandise eksklusif bertema “Chill Kill” ini berisi satu set perangko dekoratif bergaya retro dengan desain visual khas era comeback Red Velvet “Chill Kill”. Di dalamnya terdapat sheet stamp art, sticker motif member, dan amplop mini. Dikemas dalam paket elegan dengan nuansa merah gelap dan sentuhan vintage. Cocok untuk koleksi ReVeluv yang suka barang-barang aesthetic dan unik, atau untuk dekorasi journaling dan scrapbook!', 'tersedia'),
(41, 3, 'ROSÉ – ROSIE / First Studio Album Vinyl (Vampirehollie Edition – Clear)', 850000, 'gqRxduiaFa119L4nAvJv.jpg', 'Deskripsi: Vinyl edisi kolektor dari ROSÉ (BLACKPINK) bertajuk ROSIE ini hadir dalam Vampirehollie Edition dengan pressing transparan (clear vinyl) yang super aesthetic dan langka. Desain cover album menampilkan konsep dreamy-gothic dengan tone gelap elegan, dan packaging full art exclusive hanya tersedia dalam edisi ini. Dalam paket termasuk photobook mini, lyric sheet, dan postcard eksklusif. Cocok banget buat BLINK dan kolektor yang menginginkan rilisan fisik spesial dan artistik dari Rosé.', 'tersedia'),
(42, 1, 'BLACKPINK - BORN PINK / 2ND FULL ALBUM BOX SET (BLACK ver.)', 520000, 'ch7sq7ZNKooA6UG0CNWa.jpg', 'Deskripsi: Album box set edisi BLACK ver. dari full album ke-2 BLACKPINK, BORN PINK, hadir dengan tampilan mewah dan elegan dalam balutan warna hitam matte. Di dalam paket terdapat CD, photobook eksklusif, postcard set, folded poster, lyric book, large photocard, random photocard (1 dari 8), dan sticker sheet. Desain box kokoh dan premium, cocok untuk koleksi jangka panjang. Album ini menampilkan hits global seperti &quot;Pink Venom&quot; dan &quot;Shut Down&quot;. Wajib dimiliki oleh setiap BLINK yang ingin dukung BLACKPINK dengan penuh gaya!', 'tersedia'),
(43, 3, 'ITZY – 04 Disposable Camera &amp; Film Bookmark Set', 480000, 'zv0kCVICvmcsygTEeNd4.jpg', 'Deskripsi: Merchandise spesial dari ITZY 2021 Best Friend’s Store ini menghadirkan nuansa retro dengan kamera disposable eksklusif berdesain fun &amp; colorful bertema persahabatan. Satu set ini dilengkapi dengan film-style bookmark yang menampilkan potret candid para member ITZY. Cocok banget untuk MIDZY yang suka konsep nostalgia, dokumentasi ala old-school, dan collectible merch yang unik. Paket dikemas dalam box edisi terbatas dan pastinya memorable banget buat fans!', 'tersedia'),
(44, 1, ' IVE – I’ve IVE (1st Full Album)', 360000, 'ekqsK06bQDskccjGdRzq.jfif', 'Deskripsi: Album penuh pertama dari IVE ini hadir dalam berbagai versi dengan konsep visual yang bold dan elegan. Setiap paket berisi CD, photobook eksklusif, lyric book, photocard (random member), folded poster, dan sticker pack. Lagu-lagu hits seperti “I AM” dan “Kitsch” menjadi highlight utama. Wajib dikoleksi oleh DIVE yang ingin merayakan era penuh percaya diri dari IVE!', 'tersedia'),
(45, 2, ' IVE – Official Light Stick', 720000, 'jJDLbA9LUgsT6DEHCe97.jpg', 'Deskripsi: Lightstick resmi IVE dengan desain sleek dan futuristik yang menampilkan logo grup di bagian atas. Warna dominan putih dengan LED multicolor yang dapat disesuaikan, serta mendukung concert sync mode via Bluetooth. Dilengkapi dengan pouch, strap, dan box packaging eksklusif. Stylish dan elegan—cocok banget untuk DIVE yang ingin tampil all-out saat mendukung IVE di konser!', 'tersedia'),
(47, 2, 'TWICE – Candy Bong ∞ (Infinite) Light Stick Ver. 3', 730000, 'fGXpNOqbKLH37ZJu472t.jpg', '                        Deskripsi: Versi terbaru dari light stick TWICE ini hadir dengan desain infinity mirror super estetik dan nuansa putih elegan. Dilengkapi LED multicolor yang mendukung Bluetooth concert sync, efek nyala 360° memukau, dan detail logo TWICE di tengah. Desainnya lebih ramping dan ringan dari versi sebelumnya, hadir lengkap dengan pouch, strap, photocard, dan box eksklusif. Item wajib bagi ONCE yang ingin tampil stunning di konser!                    ', 'tersedia'),
(48, 3, 'TWICE – Candybong Z Wireless Charger', 420000, 'kZKVr2q0aExiO1pbzHLq.jpg', 'Deskripsi: Wireless charger eksklusif untuk Candybong Z, dirancang agar kamu bisa mengisi daya light stick dengan mudah dan aman. Memiliki desain bundar putih dengan logo TWICE di tengah, dilengkapi dengan LED indikator dan kabel USB. Kompatibel untuk Candybong Z dan juga bisa digunakan untuk perangkat lain yang mendukung wireless charging. Aesthetic, praktis, dan cocok jadi bagian dari meja ONCE sejati!', 'tersedia'),
(50, 2, ' Girls’ Generation – Official Light Stick', 650000, 'Y847cL9YXbE7ZNHkASMm.jfif', 'Deskripsi: Lightstick resmi dari Girls’ Generation (SNSD) hadir dengan desain elegan berwarna putih dan pink, dengan logo ikonik “♥ GG” di bagian atas berbentuk hati menyala. Memiliki fitur LED multicolor dan beberapa mode nyala, serta mendukung concert sync. Dilengkapi dengan pouch, strap, dan box eksklusif bernuansa feminin. Sempurna untuk SONE yang ingin menunjukkan dukungan di konser maupun sebagai koleksi sejarah dari girl group legendaris ini!', 'tersedia');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL,
  `produk_id` int(11) DEFAULT NULL,
  `produk_nama` varchar(255) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `metode` varchar(50) DEFAULT NULL,
  `nama_pembeli` varchar(100) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `catatan` text DEFAULT NULL,
  `tanggal` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id`, `produk_id`, `produk_nama`, `total`, `metode`, `nama_pembeli`, `alamat`, `no_hp`, `email`, `catatan`, `tanggal`) VALUES
(43, 0, ' V BTS – Mute Boston Bag (HYBE Artist-Made Collection)', 1450000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:05:18'),
(44, 1, 'æ-Bong - AESPA Official Lightstick', 780000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:05:18'),
(45, 2, 'BTS - You Never Walk Alone', 330000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:05:18'),
(46, 0, ' V BTS – Mute Boston Bag (HYBE Artist-Made Collection)', 1450000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:10:41'),
(47, 1, 'æ-Bong - AESPA Official Lightstick', 780000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:10:41'),
(48, 2, 'BTS - You Never Walk Alone', 330000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:10:41'),
(49, 0, ' V BTS – Mute Boston Bag (HYBE Artist-Made Collection)', 1450000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:26:38'),
(50, 1, 'æ-Bong - AESPA Official Lightstick', 780000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:26:38'),
(51, 2, 'BTS - You Never Walk Alone', 330000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:26:38'),
(52, 0, ' V BTS – Mute Boston Bag (HYBE Artist-Made Collection)', 1450000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:26:58'),
(53, 1, 'æ-Bong - AESPA Official Lightstick', 780000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:26:58'),
(54, 2, 'BTS - You Never Walk Alone', 330000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:26:58'),
(55, 0, ' V BTS – Mute Boston Bag (HYBE Artist-Made Collection)', 1450000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:27:52'),
(56, 1, 'æ-Bong - AESPA Official Lightstick', 780000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:27:52'),
(57, 2, 'BTS - You Never Walk Alone', 330000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:27:52'),
(58, 0, ' V BTS – Mute Boston Bag (HYBE Artist-Made Collection)', 1450000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:28:25'),
(59, 1, 'æ-Bong - AESPA Official Lightstick', 780000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:28:25'),
(60, 2, 'BTS - You Never Walk Alone', 330000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:28:25'),
(61, 0, ' V BTS – Mute Boston Bag (HYBE Artist-Made Collection)', 1450000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:30:17'),
(62, 1, 'æ-Bong - AESPA Official Lightstick', 780000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:30:17'),
(63, 2, 'BTS - You Never Walk Alone', 330000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:30:17'),
(64, 0, ' V BTS – Mute Boston Bag (HYBE Artist-Made Collection)', 1450000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:37:02'),
(65, 1, 'æ-Bong - AESPA Official Lightstick', 780000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:37:02'),
(66, 2, 'BTS - You Never Walk Alone', 330000, 'QRIS', 'azalea ayuni', 'komplek kodam, jakarta selatan', '085214382653', 'azaleayuni@gmail.com', 'yang rapih ', '2025-06-28 11:37:02'),
(67, 41, 'ARMY BOMB (Ver.4) – BTS Lightstick', 750000, 'QRIS', 'yasmine lavinia', 'saikin, pondok pinang', '085727359844', 'yasminevinia@gmail.com', 'banyakin freebies', '2025-06-28 13:07:39'),
(68, 42, 'Red Velvet – STAMP PACKAGE _ Chill Kill', 310000, 'QRIS', 'yasmine lavinia', 'saikin, pondok pinang', '085727359844', 'yasminevinia@gmail.com', 'banyakin freebies', '2025-06-28 13:07:39'),
(69, 0, 'ROSÉ – ROSIE / First Studio Album Vinyl (Vampirehollie Edition – Clear)', 850000, 'QRIS', 'masya nadyasmara', 'pondok pinang', '082112678956', 'masyanad@gmail.com', 'pastiin pengemasannya aman min', '2025-06-30 16:37:25'),
(70, 1, ' Girls’ Generation – Official Light Stick', 1300000, 'QRIS', 'masya nadyasmara', 'pondok pinang', '082112678956', 'masyanad@gmail.com', 'pastiin pengemasannya aman min', '2025-06-30 16:37:25'),
(71, 2, 'AESPA – MY WORLD (3rd Mini Album)', 320000, 'QRIS', 'masya nadyasmara', 'pondok pinang', '082112678956', 'masyanad@gmail.com', 'pastiin pengemasannya aman min', '2025-06-30 16:37:25');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2a$12$OSBI8kjwxXGKBZqva7zF4OS1NQ.XXQYHXn8syc/goN4SfG6iLnIg2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`),
  ADD KEY `nama` (`nama`),
  ADD KEY `kategori_produk` (`kategori_id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `produk`
--
ALTER TABLE `produk`
  ADD CONSTRAINT `kategori_produk` FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
