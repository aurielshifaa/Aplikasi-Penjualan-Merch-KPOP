<?php
require "js/koneksi.php";

if (
    empty($_POST['produk']) ||
    empty($_POST['nama_pembeli']) || empty($_POST['alamat']) ||
    empty($_POST['no_hp']) || empty($_POST['email'])
) {
    echo "<script>alert('Data tidak lengkap.'); window.history.back();</script>";
    exit;
}

$produkDipilih = $_POST['produk'];
$metode = htmlspecialchars($_POST['metode']);
$nama_pembeli = htmlspecialchars($_POST['nama_pembeli']);
$alamat = htmlspecialchars($_POST['alamat']);
$no_hp = htmlspecialchars($_POST['no_hp']);
$email = htmlspecialchars($_POST['email']);
$catatan = isset($_POST['catatan']) ? htmlspecialchars($_POST['catatan']) : '-';
$tanggal = date("Y-m-d H:i:s");

$berhasil = true;
$produkStruk = [];
$totalBayar = 0;

foreach ($produkDipilih as $produk) {
    $produk_id = intval($produk['id']);
    $produk_nama = htmlspecialchars($produk['nama']);
    $jumlah = intval($produk['jumlah']);
    $harga = intval($produk['harga']);
    $total = intval($produk['total']);

    $query = mysqli_query($conn, "INSERT INTO transaksi 
        (produk_id, produk_nama, total, metode, nama_pembeli, alamat, no_hp, email, catatan, tanggal) 
        VALUES 
        ('$produk_id', '$produk_nama', '$total', '$metode', '$nama_pembeli', '$alamat', '$no_hp', '$email', '$catatan', '$tanggal')
    ");
    if (!$query) $berhasil = false;

    // Simpan data untuk struk
    $produkStruk[] = [
        'nama' => $produk_nama,
        'jumlah' => $jumlah,
        'harga' => $harga,
        'total' => $total
    ];
    $totalBayar += $total;
}

if ($berhasil) {
    // Tampilkan struk multi-produk
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <title>Bukti Pembelian</title>
        <link rel="stylesheet" href="bootstrap/bootstrap-5.3.6-dist/css/bootstrap.min.css">
        <style>
            body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%), url('../image/ATEEZ.jfif'); }
            .struk-container {
                max-width: 900px;
                margin: 30px auto;
                background: rgba(255, 255, 255, 0.95);
                backdrop-filter: blur(20px);
                border: 1px solid rgba(255, 255, 255, 0.3);
                padding: 40px;
                border-radius: 25px;
                box-shadow: 
                    0 20px 40px rgba(0,0,0,0.1),
                    0 15px 35px rgba(0,0,0,0.05),
                    inset 0 1px 0 rgba(255,255,255,0.6);
                position: relative;
                overflow: hidden;
                animation: slideIn 0.8s ease-out;
            }
        </style>
    </head>
    <body>
        <div class="struk-container">
            <h4 class="text-center">🧾 Bukti Pembelian</h4>
            <hr>
            <strong>Daftar Produk:</strong>
            <ul class="list-group mb-3">
                <?php foreach ($produkStruk as $p): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <?= htmlspecialchars($p['nama']); ?> (<?= $p['jumlah']; ?> pcs)
                        <span>Rp <?= number_format($p['total'], 0, ',', '.'); ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
            <p><strong>Total Bayar:</strong> Rp <?= number_format($totalBayar, 0, ',', '.'); ?></p>
            <p><strong>Pembeli:</strong> <?= $nama_pembeli; ?></p>
            <p><strong>Alamat:</strong> <?= $alamat; ?></p>
            <p><strong>No HP:</strong> <?= $no_hp; ?></p>
            <p><strong>Email:</strong> <?= $email; ?></p>
            <p><strong>Metode:</strong> <?= $metode; ?></p>
            <p><strong>Tanggal:</strong> <?= $tanggal; ?></p>
            <p><strong>Catatan:</strong> <?= $catatan; ?></p>
            <hr>
            <div class="text-center">
                <a href="index.php" class="btn btn-primary">Kembali ke Beranda</a>
                <button onclick="window.print()" class="btn btn-outline-success">Cetak Struk</button>
            </div>
        </div>
    </body>
    </html>
    <?php
} else {
    echo "<script>alert('Gagal menyimpan data!'); window.history.back();</script>";
}
?>