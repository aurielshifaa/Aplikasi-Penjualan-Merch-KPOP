<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Euphoria Verse | Tentang Kami</title>
    <link rel="stylesheet" href="bootstrap/bootstrap-5.3.6-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/fontawesome/fontawesome-free-6.7.2-web/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php require "navbar.php"; ?>

    <!-- banner -->
    <div class="container-fluid banner-produk d-flex align-items-center">
        <div class="container">
            <h1 class="text-white text-center">Tentang Kami</h1>
        </div>
    </div>

    <!-- main -->
    <div class="container-fluid py-5">
        <div class="container fs-5" style="text-align: justify;">
            <p>
                Hai yorobun~ Annyeong! 💜✨
                Selamat datang di Euphoria Verse, tempat paling vibes buat kamu para pecinta K-pop sejati! Di sini, kami nggak cuma jualan merch, tapi juga jadi tempat healing sekaligus surga belanja buat semua fandom. Mau kamu Army, Blink, Carat, Stay, MOA, atau apapun, kamu bakalan ngerasa kayak di rumah sendiri. Semua produk yang kami jual 100% official, lengkap mulai dari album, photocard, lightstick, hingga perintilan gemes yang bikin dompet auto goyah!
            </p>
            <p>
                Kami paham betapa pentingnya momen-momen kecil bagi seorang fans—kayak pas unboxing album dan berharap dapat photocard bias, atau waktu liat paket datang dan rasanya kayak dapet kabar dari idol langsung. Karena itu, kami selalu kasih pelayanan terbaik: pengiriman cepat, packing aman, admin fast respon dan ramah, serta stok yang terus update biar kamu nggak ketinggalan comeback idola kamu. Di balik layar, kami juga fans yang ngerti banget rasanya nunggu PO, war tiket, atau cari photocard langka!
            </p>
            <p>
                Euphoria Verse bukan sekadar toko, tapi juga ruang komunitas yang terbuka buat kamu seru-seruan, cari mutual, atau sekadar fangirling bareng. Kami aktif banget di sosial media, sering adain giveaway, update info comeback, dan ngobrol santai seputar dunia K-pop. So, yuk jadi bagian dari keluarga Euphoria Verse dan rasain serunya belanja merch sambil tetap connect sama vibes dunia per-idolan. Karena buat kami, kebahagiaan kamu adalah ultimate bias kami! 💖
            </p>
        </div>
    </div>

    <!-- footer -->
    <?php require "footer.php"; ?>
    
    <script src="bootstrap/bootstrap-5.3.6-dist/js/bootstrap.bundle.min.js"></script>
    <script src="fontawesome/fontawesome/fontawesome-free-6.7.2-web/js/all.min.js"></script>
</body>
</html>