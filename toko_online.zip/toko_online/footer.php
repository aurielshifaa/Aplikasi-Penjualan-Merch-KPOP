<div class="container-fluid py-5 content-subscribe text-light">
    <div class="container">
        <h5 class="text-center mb-4">Temui Kami</h5>
        <div class="row justify-content-center">
            <div class="col-sm-1 d-flex justify-content-center mb-2">
                <a href="https://www.facebook.com/Unindraku"><i class="fab fa-facebook fs-2"></i></a>
            </div>
            <div class="col-sm-1 d-flex justify-content-center mb-2">
                <a href="https://www.instagram.com/unindra.sisteminformasi?igsh=YnY2N3ZzcmdpZ2di"><i class="fab fa-instagram fs-2"></i></a>
            </div>
            <div class="col-sm-1 d-flex justify-content-center mb-2">
                <i class="fab fa-twitter fs-2"></i>
            </div>
            <div class="col-sm-1 d-flex justify-content-center">
                <a href="https://youtube.com/@officialunindra?si=zwmlkR2HGsGJxEW9"><i class="fab fa-youtube fs-2"></i></a>
            </div>
            <div class="col-sm-1 d-flex justify-content-center">
                <a href="https://wa.me/+6282124610598"><i class="fab fa-whatsapp fs-2"></i></a>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid py-3 bg-dark text-light">
    <div class="container d-flex justify-content-between">
        <label>&copy;2025 Euphoria Verse</label>
        <label>Created by 750</label>
    </div>
</div>