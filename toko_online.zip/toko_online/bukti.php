<?php
session_start();
if (!isset($_SESSION['keranjang'])) {
    echo "Keranjang kosong!";
    exit;
}
$total = 0;
echo "<h2>Bukti Pembelian</h2>";
echo "<table border='1'>";
echo "<tr><th>Produk</th><th>Jumlah</th><th>Harga</th><th>Subtotal</th></tr>";
foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) {
    // ambil data produk dari DB
    $produk = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM produk WHERE id='$id_produk'"));
    $subtotal = $produk['harga'] * $jumlah;
    $total += $subtotal;
    echo "<tr><td>{$produk['nama']}</td><td>$jumlah</td><td>{$produk['harga']}</td><td>$subtotal</td></tr>";
}
echo "</table>";
echo "<h4>Total: Rp " . number_format($total) . "</h4>";
echo "<p>Tanggal: " . date('d-m-Y H:i') . "</p>";
?>
