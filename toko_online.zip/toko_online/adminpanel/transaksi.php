<?php
require "../js/koneksi.php";
$query = mysqli_query($conn, "SELECT * FROM transaksi ORDER BY tanggal DESC");
?>

<h2>Daftar Transaksi</h2>
<table border="1" cellpadding="10">
    <tr>
        <th>Nama</th>
        <th>Total</th>
        <th>Metode</th>
        <th>Bukti</th>
        <th>Status</th>
        <th>Tanggal</th>
    </tr>
    <?php while($row = mysqli_fetch_array($query)) { ?>
    <tr>
        <td><?php echo $row['nama_pembeli']; ?></td>
        <td>Rp. <?php echo number_format($row['total'],0,',','.'); ?></td>
        <td><?php echo $row['metode']; ?></td>
        <td><img src="../<?php echo $row['bukti']; ?>" width="100"></td>
        <td><?php echo $row['status']; ?></td>
        <td><?php echo $row['tanggal']; ?></td>
    </tr>
    <?php } ?>
</table>
