<?php 
    $host = "localhost";
    $user = "root";
    $password = "";
    $dbname = "toko_online";
    $port = 3306;

    $conn = new mysqli($host, $user, $password, $dbname, $port);

    if ($conn->connect_error) {
        die("koneksi gagal: " . $conn->connect_error);
    }
?>