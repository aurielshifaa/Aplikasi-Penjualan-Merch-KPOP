<?php
session_start();
require "js/koneksi.php";

// Validasi input nama
if (!isset($_GET['nama']) || $_GET['nama'] === '') {
    echo "<script>alert('Produk tidak ditemukan.'); window.location.href='index.php';</script>";
    exit;
}

// Ambil produk berdasarkan nama
$nama = htmlspecialchars($_GET['nama']);
$queryProduk = mysqli_query($conn, "SELECT * FROM produk WHERE nama='$nama'");
$produk = mysqli_fetch_array($queryProduk);

// Jika produk tidak ditemukan
if (!$produk) {
    echo "<script>alert('Produk tidak tersedia.'); window.location.href='index.php';</script>";
    exit;
}

// Ambil produk terkait
$queryProdukTerkait = mysqli_query($conn, "SELECT * FROM produk WHERE kategori_id='{$produk['kategori_id']}' AND id!='{$produk['id']}' LIMIT 4");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Euphoria Verse | Detail Produk</title>
    <link rel="stylesheet" href="bootstrap/bootstrap-5.3.6-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/fontawesome/fontawesome-free-6.7.2-web/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php require "navbar.php"; ?>

    <!-- detail produk -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 mb-3">
                    <img src="image/<?php echo $produk['foto']; ?>" class="w-100" alt="">
                </div>
                <div class="col-lg-6 offset-lg-1">
                    <h1><?php echo $produk['nama']; ?></h1>
                    <p class="fs-5" style="text-align: justify;"><?php echo $produk['detail']; ?></p>
                    <p class="text-harga">Rp. <?php echo number_format($produk['harga'], 0, ',', '.'); ?></p>
                    <p class="fs-5">Status Ketersediaan: <strong><?php echo $produk['ketersediaan_stok']; ?></strong></p>

                    <!-- Form Tambah ke Keranjang -->
                    <form id="formKeranjang" class="mb-3">
                        <input type="hidden" name="produk_id" value="<?php echo $produk['id']; ?>">
                        <input type="hidden" name="nama" value="<?php echo $produk['nama']; ?>">
                        <input type="hidden" name="harga" value="<?php echo $produk['harga']; ?>">

                        <div class="mb-3 mt-3">
                            <label for="jumlah" class="form-label">Jumlah</label>
                            <input type="number" name="jumlah" id="jumlah" value="1" min="1" max="<?php echo $produk['ketersediaan_stok']; ?>" class="form-control w-25" required>
                        </div>

                        <div class="d-flex flex-wrap gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="fa fa-cart-plus"></i> Tambah ke Keranjang
                            </button>

                            <button type="button" class="btn btn-success" onclick="konfirmasiBeli('<?php echo $produk['id']; ?>', '<?php echo htmlspecialchars($produk['nama'], ENT_QUOTES); ?>', '<?php echo $produk['harga']; ?>')">
                                <i class="fa-solid fa-bolt"></i> Beli Sekarang
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- produk terkait -->
    <div class="container-fluid py-5 warna2">
        <div class="container">
            <h2 class="text-center text-white mb-5">Produk Terkait</h2>
            <div class="row">
                <?php while ($data = mysqli_fetch_array($queryProdukTerkait)) { ?>
                    <div class="col-md-6 col-lg-3 mb-3">
                        <a href="produk-detail.php?nama=<?php echo urlencode($data['nama']); ?>">
                            <img src="image/<?php echo $data['foto']; ?>" class="img-fluid img-thumbnail produk-terkait-image" alt="">
                        </a>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>

    <?php require "footer.php"; ?>

    <script src="bootstrap/bootstrap-5.3.6-dist/js/bootstrap.bundle.min.js"></script>
    <script src="fontawesome/fontawesome/fontawesome-free-6.7.2-web/js/all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- JS Interaktif -->
    <script>
        // Tombol tambah ke keranjang pakai fetch (AJAX)
        document.getElementById('formKeranjang').addEventListener('submit', function(e) {
            e.preventDefault();

            const formData = new FormData(this);

            fetch('tambah-keranjang.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(res => {
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: 'Produk berhasil ditambahkan ke keranjang.',
                    timer: 2000,
                    showConfirmButton: false
                });
            })
            .catch(err => {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops!',
                    text: 'Gagal menambahkan produk ke keranjang.'
                });
            });
        });

        // Tombol Beli Sekarang dengan popup konfirmasi
        function konfirmasiBeli(id, nama, harga) {
            const jumlah = document.getElementById('jumlah').value;
            const total = harga * jumlah;
            const formatTotal = Number(total).toLocaleString('id-ID');

            Swal.fire({
                title: 'Konfirmasi Pembelian',
                html: `Yakin ingin membeli <b>${nama}</b> sebanyak <b>${jumlah}</b> pcs seharga <b>Rp ${formatTotal}</b>?`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Ya, Beli Sekarang',
                cancelButtonText: 'Batal',
                confirmButtonColor: '#28a745',
                cancelButtonColor: '#d33'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `checkout.php?id=${id}&nama=${encodeURIComponent(nama)}&harga=${harga}&jumlah=${jumlah}&total=${total}`;
                }
            });
        }
    </script>
</body>
</html>
