<?php
require "js/koneksi.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_POST['produk']) && !empty($_POST['produk'])) {
    $produkDipilih = $_POST['produk'];
} elseif (isset($_GET['id'], $_GET['nama'], $_GET['harga'], $_GET['jumlah'], $_GET['total'])) {
    $produkDipilih = [
        $_GET['id'] => [
            'id' => $_GET['id'],
            'nama' => $_GET['nama'],
            'harga' => $_GET['harga'],
            'jumlah' => $_GET['jumlah'],
            'total' => $_GET['total']
        ]
    ];
} else {
    die("Tidak ada produk yang dipilih untuk checkout.");
}

$totalBayar = 0;
$jumlahItem = isset($_SESSION['keranjang']) ? count($_SESSION['keranjang']) : 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Checkout</title>
    <link rel="stylesheet" href="bootstrap/bootstrap-5.3.6-dist/css/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        body {
             background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .checkout-container {
            max-width: 950px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 
                0 15px 35px rgba(0,0,0,0.1),
                0 5px 15px rgba(0,0,0,0.07);
            border: 1px solid rgba(255,255,255,0.2);
            position: relative;
            overflow: hidden;
        }

        .checkout-container input.form-control,
        .checkout-container textarea.form-control {
            width: 100%; /* Lebarkan input dan textarea */
            font-size: 1rem;
        }

        .warna1 {
            background-color: #3c0663;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark warna1">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false"
                aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item me-4"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item me-4"><a class="nav-link" href="tentang-kami.php">Tentang Kami</a></li>
                <li class="nav-item me-4"><a class="nav-link" href="produk.php">Produk</a></li>
            </ul>
            <ul class="navbar-nav mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link position-relative" href="keranjang.php">
                        <i class="fas fa-shopping-cart"></i> Keranjang
                        <?php if ($jumlahItem > 0): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                <?= $jumlahItem; ?>
                            </span>
                        <?php endif; ?>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container-lg py-5 d-flex justify-content-center">
    <div class="checkout-container">
        <h3 class="mb-4">Checkout Produk</h3>

        <ul class="list-group mb-4">
            <?php foreach ($produkDipilih as $id => $produk): ?>
                <?php
                $subtotal = intval($produk['total']);
                $totalBayar += $subtotal;
                ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <?= htmlspecialchars($produk['nama']); ?> (<?= $produk['jumlah']; ?> pcs)
                    <span class="badge bg-success rounded-pill">Rp <?= number_format($subtotal, 0, ',', '.'); ?></span>
                </li>
            <?php endforeach; ?>
        </ul>

        <h5 class="text-end mb-4">Total Bayar:
            <span class="text-success fw-bold">Rp <?= number_format($totalBayar, 0, ',', '.'); ?></span>
        </h5>

        <div class="text-center mb-4">
            <p class="mb-2">Scan QRIS berikut untuk pembayaran:</p>
            <img src="image/5f7c6da47a380-qr-code-dana.jpg" alt="QRIS" width="250">
        </div>

        <form action="proses-pembayaran.php" method="POST">
            <?php foreach ($produkDipilih as $id => $produk): ?>
                <input type="hidden" name="produk[<?= $id ?>][id]" value="<?= $id ?>">
                <input type="hidden" name="produk[<?= $id ?>][nama]" value="<?= htmlspecialchars($produk['nama']) ?>">
                <input type="hidden" name="produk[<?= $id ?>][harga]" value="<?= $produk['harga'] ?>">
                <input type="hidden" name="produk[<?= $id ?>][jumlah]" value="<?= $produk['jumlah'] ?>">
                <input type="hidden" name="produk[<?= $id ?>][total]" value="<?= $produk['total'] ?>">
            <?php endforeach; ?>

            <input type="hidden" name="total_bayar" value="<?= $totalBayar ?>">
            <input type="hidden" name="metode" value="QRIS">

            <div class="mb-3">
                <label class="form-label">Nama Pembeli</label>
                <input type="text" name="nama_pembeli" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Alamat Lengkap</label>
                <textarea name="alamat" class="form-control" rows="2" required></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Nomor HP</label>
                <input type="tel" name="no_hp" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Catatan Tambahan (Opsional)</label>
                <textarea name="catatan" class="form-control" rows="2"></textarea>
            </div>

            <div class="d-grid">
                <button type="submit" class="btn btn-success btn-lg">Konfirmasi Pembayaran</button>
            </div>
        </form>
    </div>
</div>

<script src="bootstrap/bootstrap-5.3.6-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>